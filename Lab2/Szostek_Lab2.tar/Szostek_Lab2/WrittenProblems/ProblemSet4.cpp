/*
Quiz - Google for Education

Question 1:
Answer: A

Question 3:
Answer: B

Question 5:
Answer: C

Question 6:
Answer: A,C,D,E,F

Question 7:
Answer: A,B

Question 9:
Answer: C 
*/
